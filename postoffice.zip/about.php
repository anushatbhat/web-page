<!DOCTYPE html>
<html>

<head> <title> Home Page </title>

</head>
<style>
        .a{
            text-align: center;
            border: 3px solid red; 
            font-family:"times new roman",serif;
            background-color:lightsalmon;
        }
        .container{  
text-align: center;  

width: 300px;  
height: 200px;  
padding-top: 30px; 


} 
.b{
    height:40px;
    width:120px;
}
.c{
    font-color: black;
}

    
#btn{  
font-size: 25px;  
}
        </style>

▾ <body>
    <marquee>
      <P>  PAY THE BILL BEFORE DUE-DATE TO AVOID PENALTY.NOT PAYING DUE-AMOUNT INCREASES PENALTY</P> </marquee>
<div class="Loginbox">
     <br><br>

    <h1 class="a">About</h1>
    <div class="c">
    <form action="front.php" method="post" style="text-align:center;">
      <p>
      Internet and e-mail have revolutionized the world of communications. At the same time, accessibility to email continues to be a major problem for many people, especially in the rural areas.<br>
       In its endeavor to make benefits of e-mail available to everyone and to bridge the digital divide, Department of Posts has introduced ePOST service.<br>

Through ePOST, customers can send their messages to any address in India with a combination of electronic transmission and physical delivery through a network of more than 1,55,000 Post Offices.<br>
 ePOST sends messages as a soft copy through internet and at the destination it will be delivered to the addressee in the form of hard copy<br>

ePOST can also be availed by the corporate customers, by having a business agreement with India Post. Corporate customers will get special ePOST rates and other value additions.
</p><br>
<input type='submit' value='HOME' id="submit"/>


</form>



<form action='front.php' method="POST" style="text-align:center;">

       </form>


</form>
</div>
</body>
</html>
