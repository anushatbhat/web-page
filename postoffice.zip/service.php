<!DOCTYPE html>
<html>

<head> <title> Home Page </title>

</head>
<style>
        .a{
            text-align: center;
            border: 3px solid red; 
            font-family:"times new roman",serif;
            background-color:lightsalmon;
        }
        .container{  
text-align: center;  

width: 300px;  
height: 200px;  
padding-top: 30px; 


} 
.b{
    height:40px;
    width:120px;
}
.c{
    font-color: black;
}

    
#btn{  
font-size: 25px;  
}
        </style>

▾ <body>
    <marquee>
      <P>  PAY THE BILL BEFORE DUE-DATE TO AVOID PENALTY.NOT PAYING DUE-AMOUNT INCREASES PENALTY</P> </marquee>
<div class="Loginbox">
     <br><br>

    <h1 class="a">e-Post Office service of India </h1>
    <div class="c">
    <form action="front.php" method="post" style="text-align:center;">
      <p>
      The ePost Office of India Post offers variety of online Postal services to the users.<br>
       One can avail services such as sending an Electronic Money Order (EMO), Instant Money Order (IMO), philately etc.<br>
        Users can also track and trace Speed Post, EMO, WorldNet Express (WNX), international mail, paying premium and searching pin codes. <br>
        Information related to Postal Life Insurance (PLI), banking, speed post, business post, logistics post and other related services is also provided.
</p>
</form>



<form action='front.php' method="POST" style="text-align:center;">
<input type='submit' name='Save ebill' value="HOME" id="submit"/>
       </form>


</form>
</div>
</body>
</html>