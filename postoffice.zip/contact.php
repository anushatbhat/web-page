<!DOCTYPE html>
<html>

<head> <title> Home Page </title>

</head>
<style>
        .a{
            text-align: center;
            border: 3px solid red; 
            font-family:"times new roman",serif;
            background-color:lightsalmon;
        }
        .container{  
text-align: center;  

width: 300px;  
height: 200px;  
padding-top: 30px; 


} 
.b{
    height:40px;
    width:120px;
}
.c{
    font-color: black;
}

    
#btn{  
font-size: 25px;  
}
        </style>

▾ <body>
    <marquee>
      <P>  PAY THE BILL BEFORE DUE-DATE TO AVOID PENALTY.NOT PAYING DUE-AMOUNT INCREASES PENALTY</P> </marquee>
<div class="Loginbox">
     <br><br>

    <h1 class="a">Contact Us</h1>
    <div class="c">
    <form action="front.php" method="post" style="text-align:center;">
      <p>

For further details and business requirements, contact Business Development Cell of your Circle<br>

​OR<br>
Business Development Directorate<br>
Department of Posts, Ministry of Communications,<br>
Dak Bhawan, Sansad Marg,<br>
New Delhi - 110 001<br>
Tel: 91-11-23096110.<br>
Toll free No. : 1800-11-8282</p>
</form>



<form action='front.php' method="POST" style="text-align:center;">
<input type='submit' name='Save ebill' value="HOME" id="submit"/>
       </form>


</form>
</div>
</body>
</html>
